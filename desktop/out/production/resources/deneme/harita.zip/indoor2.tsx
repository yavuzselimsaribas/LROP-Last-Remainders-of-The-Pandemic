<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="indoor2" tilewidth="16" tileheight="16" tilecount="84" columns="7">
 <image source="tilesetformattedupdate1.png" width="112" height="192"/>
 <tile id="0">
  <animation>
   <frame tileid="41" duration="90"/>
   <frame tileid="48" duration="90"/>
  </animation>
 </tile>
 <tile id="27">
  <properties>
   <property name="type" value="FIRE"/>
  </properties>
  <animation>
   <frame tileid="27" duration="150"/>
   <frame tileid="34" duration="150"/>
  </animation>
 </tile>
 <tile id="41">
  <properties>
   <property name="type" value="FIRE"/>
  </properties>
  <animation>
   <frame tileid="41" duration="150"/>
   <frame tileid="48" duration="150"/>
  </animation>
 </tile>
 <tile id="49">
  <properties>
   <property name="type" value="AXE"/>
  </properties>
 </tile>
</tileset>
