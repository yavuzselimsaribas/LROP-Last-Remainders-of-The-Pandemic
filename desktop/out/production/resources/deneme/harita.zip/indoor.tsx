<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="indoor" tilewidth="16" tileheight="16" tilecount="324" columns="18">
 <image source="../../../tileset_for_rpg_maker_mv___sf_outside_ba_by_chibimaronchan_daz7gji-300w.png" width="300" height="300"/>
</tileset>
