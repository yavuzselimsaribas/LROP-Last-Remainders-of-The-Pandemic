<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="labtileset1" tilewidth="16" tileheight="16" tilecount="1024" columns="32">
 <image source="labtileset1.png" width="512" height="512"/>
</tileset>
